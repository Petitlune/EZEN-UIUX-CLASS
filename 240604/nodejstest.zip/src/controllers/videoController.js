import Video from "../models/Video";

// export const home = (req, res) => {
//   console.log("Start");
//   Video.find()
//     .then((videos) => {
//       console.log("videos", videos);
//       return res.render("home", { pageTitle: "Home", videos: [] });
//     })
//     .catch((err) => console.log("errors", err));
// };

// export const home = async (req, res) => {
//   console.log("Start");
//   const videos = await Video.find({});
//   console.log("Finished");
//   console.log(videos);
//   return res.render("home", { pageTitle: "Home", videos });
// };

export const home = async (req, res) => {
  try {
    const videos = await Video.find({});
    console.log(videos);
    return res.render("home", { pageTitle: "Home", videos });
  } catch (error) {
    return res.render("Server-error", { error });
  }
};

export const watch = async (req, res) => {
  const { id } = req.params;
  //findById함수 사용
  const video = await Video.findById(id);
  //if문으로 예외조항 처리
  if (!video) {
    return res.render("404", { pageTitle: "Video not Found" });
  }
  return res.render("watch", {
    pageTitle: video.title,
    video,
  });
};

export const getEdit = async (req, res) => {
  const { id } = req.params;
  const video = await Video.findById(id);
  if (!video) {
    return res.render("404", { pageTitle: "Video not Found" });
  }
  return res.render("edit", {
    pageTitle: `Edit ${video.title}`,
    video,
  });
  // return res.render("edit", { pageTitle: `Editing` });
};

export const postEdit = async (req, res) => {
  const { id } = req.params;
  const { title, description, hashtags } = req.body;
  const video = await Video.findById(id);
  if (!video) {
    return res.render("404", { pageTitle: "Video not Found" });
  }
  //한큐에 가져오기 위해 monogoose에서 findByIdAndUpdate()함수 사용
  await Video.findByIdAndUpdate(id, {
    title,
    description,
    //기존 hash가 붙은 태그에는 중복으로 붙지 않기 위해 startsWith()함수로 첫번재 문자가 무엇인지 판별하고 삼항조건 연산자로 조건을 줌
    hashtages: hashtags
      .split(",")
      .map((word) => (word.startsWith("#") ? word : `#${word}`)),
  });
  await video.save();
  return res.redirect(`/videos/${id}`);
};

export const getUpload = (req, res) => {
  return res.render("upload", {
    pageTitle: "Upload Video",
  });
};

export const postUpload = async (req, res) => {
  const { title, description, hashtags } = req.body;
  try {
    await Video.create({
      title,
      description,
      // createdAt: Date.now(),
      hashtags: hashtags
        .split(",")
        .map((word) => (word.startsWith("#") ? word : `#${word}`)),
      // meta: {
      //   views: 0,
      //   rating: 0,
      // },
    });
    //save함수를 사용해야 실제로 스키마형태의 모델의 값으로 데이터베이스에 저장됨
    // const dbVideo = await video.save();
    // console.log(dbVideo);
    return res.redirect("/");
  } catch (err) {
    console.log(err);
    return res.render("upload", {
      pageTitle: "upload video",
      errorMessage: err._message,
    });
  }
  //데이터 생성과 동시에 db로 보내고 싶을때 사용하는 함수 create()
};

export const search = (req, res) => {
  return res.send("Search");
};

export const deleteVideo = (req, res) => {
  return res.send("Delete Video");
};
